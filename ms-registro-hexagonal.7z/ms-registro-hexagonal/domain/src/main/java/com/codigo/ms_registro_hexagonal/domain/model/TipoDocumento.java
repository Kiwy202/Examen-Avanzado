package com.codigo.ms_registro_hexagonal.domain.model;

public enum TipoDocumento {
    DNI, PASAPORTE, CARNET_EXT;
}
