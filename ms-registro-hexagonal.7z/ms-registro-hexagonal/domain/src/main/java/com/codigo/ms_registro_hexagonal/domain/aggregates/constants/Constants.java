package com.codigo.ms_registro_hexagonal.domain.aggregates.constants;

public class Constants {
    public static final String LOG_INICIO = "Se inicia la ejecución del Metodo: ";
    public static final String LOG_FIN = "Se Finaliza la ejecución del Metodo: ";
    public static final String LOG_ERROR = "Se ha producido un error la ejecución del Metodo: ";


}

